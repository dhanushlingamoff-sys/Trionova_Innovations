<!DOCTYPE html>
<html>

    <head>
          @yield('meta')
          
    <meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1">
           <link rel="shortcut icon" href="{{ asset('images/trionova/favicon.png') }}">
     <link rel="apple-touch-icon" href="{{ asset('images/apple-touch-icon-57x57.png') }}">
     <link rel="apple-touch-icon" sizes="72x72" href="{{ asset('images/apple-touch-icon-72x72.png') }}">
     <link rel="apple-touch-icon" sizes="114x114" href="{{ asset('images/apple-touch-icon-114x114.png') }}">

     <!-- google fonts preconnect -->
     <link rel="preconnect" href="https://fonts.googleapis.com" crossorigin>
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <!-- style sheets and font icons -->
     <!-- Font -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
     <link rel="stylesheet" href="{{ asset('css/icon.min.css') }}" />

     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
         integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
         crossorigin="anonymous" referrerpolicy="no-referrer" />
         
         
     {{-- <link rel="stylesheet" href="{{ asset('css/flaticon.css') }}?v=1.0"> --}}
     
     <link rel="stylesheet" href="{{ asset('css/style.css') }}?v=1.0" />
     <link rel="stylesheet" href="{{ asset('css/responsive.css') }}?v=1.0" />
     <link rel="stylesheet" href="{{ asset('css/vendors.min.css') }}?v=1.0" />
     
     
     {{-- <link rel="stylesheet" type="text/css" href="{{ asset('/css/rs-spacing.css') }}"> --}}

     <link rel="stylesheet" type="text/css" href="{{ asset('/css/flutter.css') }}?v=1.0">
     <!-- style sheets and font icons -->
     <!-- Font -->
     <link
         href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700;9..40,800&amp;display=swap"
         rel="stylesheet">
     <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&amp;display=swap"
         rel="stylesheet">
     <link href="https://fonts.googleapis.com/css2?family=Lily+Script+One&amp;display=swap" rel="stylesheet">
     {{-- <link rel="stylesheet" type="text/css" href="{{ asset('/css/off-canvas.css') }}?v=1.0"> --}}
     <link rel="stylesheet" type="text/css" href="{{ asset('/css/animate.css') }}?v=1.0">
     <link rel="stylesheet" type="text/css" href="{{ asset('/css/owl.carousel.css') }}">
     <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">          
    <link rel="shortcut icon" href="{{ asset('images/favicon.png') }}">
    </head>
<body>

{{-- start pre-loader --}}
        @include('common.preloader')
        {{-- End pre-loader --}}
   
 {{-- Include the header --}}
    @include('partials.header')

    {{-- Page Content --}}
    <div class="main-content">
        @yield('content')
    </div>

    {{-- Include the footer --}}
    @include('partials.footer')
    @yield('scripts')
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    
</body>

</html>
